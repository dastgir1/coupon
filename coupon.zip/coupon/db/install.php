<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_auth_coupon_install()
{
    // Installation logic, if required.
}
